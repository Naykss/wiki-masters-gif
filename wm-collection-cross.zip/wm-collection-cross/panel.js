'use strict';
/* global cle, estGif, estWikimedia, fusion */

const api = globalThis.browser || globalThis.chrome;
const $ = (id) => document.getElementById(id);

let scan = [];            // liens uniques trouvés (toutes images wikimedia)
let noms = {};            // clé du GIF -> noms de cartes vus avec ce GIF
let cles = new Set();     // clés de doublon correspondantes
let opts = { gif: true, auto: false };
let resultat = null;      // dernier JSON fusionné
let occupe = false;

/* ---------- Fonction injectée : LECTURE SEULE ----------
   Tourne dans le monde isolé de l'extension (invisible pour le site).
   Ne clique rien, ne scrolle pas, ne modifie rien, n'écrit rien dans la console. */
function lirePage() {
  try {
    const norm = (v) => {
      if (!v) return '';
      const brut = String(v).trim();
      if (!brut || brut.startsWith('data:') || brut.startsWith('blob:')) return '';
      try {
        let u = new URL(brut, document.baseURI);
        let txt = /^https?:\/\//i.test(brut) ? brut : u.href;
        if (u.pathname === '/_next/image') {
          const inner = u.searchParams.get('url');
          if (!inner) return '';
          u = new URL(inner, document.baseURI);
          txt = /^https?:\/\//i.test(inner) ? inner : u.href;
        }
        if (u.protocol !== 'http:' && u.protocol !== 'https:') return '';
        return txt;
      } catch (e) { return ''; }
    };
    const items = [];
    const imgs = document.images;
    for (let i = 0; i < imgs.length; i++) {
      const img = imgs[i];
      let url = norm(img.getAttribute('src')) || norm(img.getAttribute('data-src'));
      if (!url) {
        const ss = img.getAttribute('srcset') || img.getAttribute('data-srcset');
        if (ss) { const p = ss.split(/,\s+/)[0]; if (p) url = norm(p.trim().split(/\s+/)[0]); }
      }
      const nom = (img.getAttribute('alt') || img.getAttribute('title') || '').trim();
      items.push({ nom: nom, url: url });
    }
    return { total: imgs.length, items: items };
  } catch (e) {
    return { total: 0, items: [] };
  }
}

/* ---------- Stockage ---------- */
function sauverScan() { api.storage.local.set({ scan, noms }).catch(() => {}); }
function sauverOpts() { api.storage.local.set({ opts }).catch(() => {}); }

function visibles() { return opts.gif ? scan.filter(estGif) : scan.slice(); }

function ajouterLiens(liens) {
  let nouveaux = 0, nouveauxVis = 0;
  for (const u of liens || []) {
    if (!estWikimedia(u)) continue;
    const k = cle(u);
    if (cles.has(k)) continue;
    cles.add(k);
    scan.push(u);
    nouveaux++;
    if (!opts.gif || estGif(u)) nouveauxVis++;
  }
  if (nouveaux) { sauverScan(); invaliderFusion(); }
  return nouveauxVis;
}

function ajouterNoms(items) {
  let change = false;
  for (const it of items) {
    if (!it.url || !estWikimedia(it.url)) continue;
    const k = cle(it.url);
    const n = it.nom || '(sans nom)';
    if (!noms[k]) noms[k] = [];
    if (!noms[k].includes(n)) { noms[k].push(n); change = true; }
  }
  return change;
}

function analyser(items) {
  const cartes = [], ignorees = [];
  for (const it of items) {
    if (!it.url) { if (it.nom) ignorees.push({ nom: it.nom, raison: 'pas de lien d\'image' }); continue; }
    if (!estWikimedia(it.url)) { if (it.nom) ignorees.push({ nom: it.nom, raison: 'image hors Wikimedia', url: it.url }); continue; }
    if (opts.gif && !estGif(it.url)) { ignorees.push({ nom: it.nom || '(sans nom)', raison: 'ni .gif ni .webp', url: it.url }); continue; }
    cartes.push(it);
  }
  const groupes = new Map();
  for (const c of cartes) {
    const k = cle(c.url);
    if (!groupes.has(k)) groupes.set(k, []);
    groupes.get(k).push(c);
  }
  const doublons = [...groupes.values()].filter((g) => g.length > 1);
  return { cartes, ignorees, uniques: groupes.size, doublons };
}

function el(tag, cls, txt) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (txt != null) e.textContent = txt;
  return e;
}
function ligneStat(label, val, cls) {
  const d = el('div'); d.append(el('span', null, label), el('b', cls || null, String(val))); return d;
}
function nomFichier(u) {
  const p = (cle(u).split('/').pop() || '');
  return p;
}

function rendreRapport(a) {
  const box = $('rapport');
  box.replaceChildren();
  box.className = 'stats on';
  box.append(el('div', 'titre', 'Cette page'));
  box.append(ligneStat('Cartes lues', a.cartes.length));
  box.append(ligneStat('GIF différents', a.uniques));
  box.append(ligneStat('En double sur la page', a.cartes.length - a.uniques, a.cartes.length - a.uniques ? 'warn' : null));
  box.append(ligneStat('Ignorées', a.ignorees.length, a.ignorees.length ? 'warn' : null));
  if (a.doublons.length) {
    box.append(el('div', 'sous', 'Même GIF sur plusieurs cartes :'));
    for (const g of a.doublons) {
      const li = el('div', 'item');
      li.append(el('span', null, g.map((c) => c.nom || '(sans nom)').join('  =  ')));
      li.append(el('small', null, nomFichier(g[0].url)));
      box.append(li);
    }
  }
  if (a.ignorees.length) {
    box.append(el('div', 'sous', 'Ignorées :'));
    for (const c of a.ignorees) {
      const li = el('div', 'item');
      li.append(el('span', null, c.nom + ' — ' + c.raison));
      if (c.url) li.append(el('small', null, c.url));
      box.append(li);
    }
  }
}

function rendreDoublonsTous() {
  const box = $('doublonsTous');
  box.replaceChildren();
  const groupes = [];
  for (const u of visibles()) {
    const n = noms[cle(u)];
    if (n && n.length > 1) groupes.push({ u, n });
  }
  if (!groupes.length) { box.className = 'stats'; return; }
  box.className = 'stats on';
  box.append(el('div', 'titre', 'Doublons sur tous les scans (' + groupes.length + ')'));
  box.append(el('div', 'muted', 'Cartes différentes qui ont le même GIF : un seul lien est gardé.'));
  for (const g of groupes) {
    const li = el('div', 'item');
    li.append(el('span', null, g.n.join('  =  ')));
    li.append(el('small', null, nomFichier(g.u)));
    box.append(li);
  }
}

/* ---------- Onglet actif ---------- */
function estCollection(url) {
  try {
    const u = new URL(url);
    return /(^|\.)wiki-masters\.com$/i.test(u.hostname) && /^\/collection(\/|$)/i.test(u.pathname);
  } catch (e) { return false; }
}

async function ongletActif() {
  try {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    return tab || null;
  } catch (e) { return null; }
}

function afficherPage(ok) {
  const el = $('page');
  if (ok) { el.className = 'pill ok'; el.textContent = '✓ Onglet actif : ta collection'; }
  else { el.className = 'pill warn'; el.textContent = 'Ouvre wiki-masters.com/collection dans l\'onglet actif'; }
}

const ORIGINES = { origins: ['https://www.wiki-masters.com/*', 'https://wiki-masters.com/*'] };
async function verifierPerm() {
  let ok = false;
  try { ok = await api.permissions.contains(ORIGINES); } catch (e) {}
  $('perm').hidden = ok;
  return ok;
}

async function majPage() {
  await verifierPerm();
  const tab = await ongletActif();
  afficherPage(!!tab && estCollection(tab.url));
}

async function scanner(auto) {
  if (occupe) return;
  occupe = true;
  try {
    const tab = await ongletActif();
    const ok = !!tab && estCollection(tab.url);
    afficherPage(ok);
    if (!ok) { verifierPerm(); return; }
    const res = await api.scripting.executeScript({ target: { tabId: tab.id }, func: lirePage });
    const r = res && res[0] && res[0].result;
    if (!r) return;
    const items = r.items || [];
    const n = ajouterLiens(items.map((it) => it.url).filter(Boolean));
    if (ajouterNoms(items)) { sauverScan(); invaliderFusion(); }
    if (!auto || n) {
      const h = new Date().toLocaleTimeString('fr-FR');
      $('dernier').textContent = `${h} · +${n} nouveau${n > 1 ? 'x' : ''} lien${n > 1 ? 's' : ''}`;
    }
    rendreRapport(analyser(items));
    rendreScan();
  } catch (e) {
    if (!auto) $('dernier').textContent = 'Page pas prête, réessaie dans une seconde.';
  } finally {
    occupe = false;
  }
}

function rendreScan() {
  const vis = visibles();
  $('nb').textContent = vis.length;
  const txt = vis.join('\n');
  if ($('liste').value !== txt) $('liste').value = txt;
  rendreDoublonsTous();
}

/* ---------- Fusion ---------- */
function invaliderFusion() {
  if (!resultat) return;
  resultat = null;
  $('btnDl').disabled = true;
  $('btnCopier').disabled = true;
  $('infoFusion').textContent = 'Ça a changé depuis la dernière fusion : reclique sur Fusionner.';
}

function fusionner() {
  const box = $('stats');
  const txt = $('jsonIn').value.trim();
  let data;
  if (!txt) {
    data = { app: 'wiki-masters-gif', version: 1, favs: [], cross: [] };
  } else {
    try { data = JSON.parse(txt); }
    catch (e) {
      box.className = 'stats on';
      box.innerHTML = '<span class="erreur">JSON invalide, vérifie que t\'as tout collé.</span>';
      return;
    }
  }
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    box.className = 'stats on';
    box.innerHTML = '<span class="erreur">Le texte doit être un objet {"favs":[…],"cross":[…]}.</span>';
    return;
  }

  const { resultat: res, stats: s } = fusion(data, visibles());
  resultat = res;

  box.className = 'stats on';
  box.innerHTML =
    `<div><span>Liens scannés</span><b>${s.scannes}</b></div>` +
    `<div><span>Déjà dans favs</span><b>${s.dejaFavs}</b></div>` +
    `<div><span>Déjà dans cross</span><b>${s.dejaCross}</b></div>` +
    `<div><span>Ajoutés à cross</span><b class="plus">+${s.ajoutes}</b></div>` +
    `<div><span>cross</span><b>${s.crossAvant} → ${s.crossApres}</b></div>` +
    (s.doublonsTexte ? `<span class="alerte">⚠ Ton texte contenait déjà ${s.doublonsTexte} doublon(s) entre favs/cross, laissé(s) tels quels.</span>` : '');

  $('btnDl').disabled = false;
  $('btnCopier').disabled = false;
  $('infoFusion').textContent = s.scannes ? '' : 'Rien de scanné pour l\'instant (onglet Scan).';
}

function telecharger() {
  if (!resultat) return;
  const blob = new Blob([JSON.stringify(resultat)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'galerie-sauvegarde.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

async function copier() {
  if (!resultat) return;
  try {
    await navigator.clipboard.writeText(JSON.stringify(resultat));
    $('infoFusion').textContent = 'Copié ✓';
  } catch (e) {
    $('infoFusion').textContent = 'Copie impossible, utilise Télécharger.';
  }
}

/* ---------- UI ---------- */
document.querySelectorAll('nav button').forEach((b) => {
  b.addEventListener('click', () => {
    document.querySelectorAll('nav button').forEach((x) => x.classList.toggle('on', x === b));
    document.querySelectorAll('section').forEach((s) => s.classList.toggle('on', s.id === 'tab-' + b.dataset.tab));
  });
});

$('btnScan').addEventListener('click', () => scanner(false));
$('btnPerm').addEventListener('click', () => {
  api.permissions.request(ORIGINES).then(() => majPage()).catch(() => {});
});

$('optAuto').addEventListener('change', (e) => { opts.auto = e.target.checked; sauverOpts(); });
$('optGif').addEventListener('change', (e) => { opts.gif = e.target.checked; sauverOpts(); rendreScan(); invaliderFusion(); });

let confirmVider = null;
$('btnVider').addEventListener('click', () => {
  const b = $('btnVider');
  if (!confirmVider) {
    b.textContent = 'Sûr ? Reclique pour vider';
    confirmVider = setTimeout(() => { b.textContent = 'Vider le scan'; confirmVider = null; }, 3000);
    return;
  }
  clearTimeout(confirmVider);
  confirmVider = null;
  b.textContent = 'Vider le scan';
  scan = [];
  cles = new Set();
  noms = {};
  sauverScan();
  $('rapport').className = 'stats';
  invaliderFusion();
  $('dernier').textContent = '';
  rendreScan();
});

$('jsonIn').addEventListener('input', invaliderFusion);
$('btnFichier').addEventListener('click', () => $('fichier').click());
$('fichier').addEventListener('change', async (e) => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  try { $('jsonIn').value = await f.text(); invaliderFusion(); } catch (err) {}
  e.target.value = '';
});
$('btnFusion').addEventListener('click', fusionner);
$('btnDl').addEventListener('click', telecharger);
$('btnCopier').addEventListener('click', copier);

api.tabs.onActivated.addListener(() => { majPage(); });
api.tabs.onUpdated.addListener(() => { majPage(); });

setInterval(() => { if (opts.auto) scanner(true); }, 1500);

/* ---------- Démarrage ---------- */
api.storage.local.get(['scan', 'opts', 'noms']).then((d) => {
  if (d && d.opts) opts = Object.assign(opts, d.opts);
  if (d && d.noms && typeof d.noms === 'object') noms = d.noms;
  if (d && Array.isArray(d.scan)) {
    for (const u of d.scan) {
      const k = cle(u);
      if (!cles.has(k)) { cles.add(k); scan.push(u); }
    }
  }
  $('optAuto').checked = opts.auto;
  $('optGif').checked = opts.gif;
  rendreScan();
  majPage();
}).catch(() => { rendreScan(); majPage(); });
