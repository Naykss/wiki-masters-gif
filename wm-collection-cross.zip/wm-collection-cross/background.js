'use strict';
// Clic sur l'icône = ouvre le panneau. Rien d'autre.
const api = globalThis.browser || globalThis.chrome;
if (api.sidePanel && api.sidePanel.setPanelBehavior) {
  // Chrome, Edge, Brave, Vivaldi…
  api.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
} else if (api.sidebarAction && api.sidebarAction.toggle) {
  // Firefox
  api.action.onClicked.addListener(() => { api.sidebarAction.toggle().catch(() => {}); });
}
