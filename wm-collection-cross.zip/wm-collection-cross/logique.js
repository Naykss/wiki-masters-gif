'use strict';

function versURL(u) {
  let s = String(u == null ? '' : u).trim();
  if (!s) return null;
  if (s.startsWith('//')) s = 'https:' + s;
  try { return new URL(s); } catch (e) { return null; }
}

// Clé de doublon : même fichier = même clé.
// Ignore http/https, ?utm_..., #..., et la taille de miniature (thumb/.../330px-...).
// Ex : .../commons/thumb/9/96/Engine_explosion.gif/330px-Engine_explosion.gif
//  et .../commons/9/96/Engine_explosion.gif?utm_source=...  => même clé
function cle(u) {
  const p = versURL(u);
  if (!p) return String(u == null ? '' : u).trim();
  let chemin = p.pathname;
  try { chemin = decodeURIComponent(chemin); } catch (e) {}
  chemin = chemin.replace(/ /g, '_');
  const m = chemin.match(/^\/(.+?)\/thumb\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+)\/[^/]+$/i);
  if (m) chemin = '/' + m[1] + '/' + m[2].toLowerCase() + '/' + m[3].toLowerCase() + '/' + m[4];
  return p.hostname.toLowerCase() + chemin;
}

function estWikimedia(u) {
  const p = versURL(u);
  return !!p && /(^|\.)wikimedia\.org$/i.test(p.hostname);
}

function estGif(u) {
  const p = versURL(u);
  return !!p && /\.(gif|webp)$/i.test(p.pathname);
}

// Fusion : ne touche ni à favs ni aux entrées existantes de cross.
// Ajoute seulement à la fin de cross les liens scannés absents de favs ET de cross.
function fusion(data, liens) {
  const favs = Array.isArray(data.favs) ? data.favs : [];
  const crossAvant = Array.isArray(data.cross) ? data.cross : [];

  const clesFavs = new Set();
  const clesCross = new Set();
  const tous = new Set();
  let doublonsTexte = 0;
  for (const u of favs) { const k = cle(u); if (tous.has(k)) doublonsTexte++; tous.add(k); clesFavs.add(k); }
  for (const u of crossAvant) { const k = cle(u); if (tous.has(k)) doublonsTexte++; tous.add(k); clesCross.add(k); }

  const cross = crossAvant.slice();
  const vusScan = new Set();
  let dejaFavs = 0, dejaCross = 0, doublonsScan = 0, ajoutes = 0;

  for (const u of liens) {
    const k = cle(u);
    if (vusScan.has(k)) { doublonsScan++; continue; }
    vusScan.add(k);
    if (clesFavs.has(k)) { dejaFavs++; continue; }
    if (clesCross.has(k)) { dejaCross++; continue; }
    cross.push(u);
    ajoutes++;
  }

  return {
    resultat: Object.assign({ app: 'wiki-masters-gif', version: 1 }, data, { favs, cross }),
    stats: {
      scannes: vusScan.size, dejaFavs, dejaCross, doublonsScan, ajoutes,
      crossAvant: crossAvant.length, crossApres: cross.length, doublonsTexte
    }
  };
}

if (typeof module !== 'undefined') module.exports = { cle, estGif, estWikimedia, fusion };
